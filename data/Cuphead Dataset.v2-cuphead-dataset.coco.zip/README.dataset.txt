# Cuphead Dataset > Cuphead Dataset
https://universe.roboflow.com/cuphead-model/cuphead-dataset

Provided by a Roboflow user
License: CC BY 4.0

